#ifndef LIBIPSET_XLATE_H
#define LIBIPSET_XLATE_H

int ipset_xlate_argv(struct ipset *ipset, int argc, char *argv[]);

#endif
